@extends('app')

@section('css')
<link rel="stylesheet" href="{{asset('css/base.css')}}">

@section('img','original.png')
@section('tittle','Bienvenido!!')

<div class='clear'></div>
<div class='clear'></div>
