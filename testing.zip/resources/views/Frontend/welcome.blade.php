@extends('app')
@section('msg','Esta es nuestra pagina principal donde podrás estar en contacto con nosotros y estar al dia de todos nuestros productos, ofertas y servicios.')
@section('css')
<link rel="stylesheet" href="{{asset('css/base.css')}}">

@section('img','original.png')
@section('tittle','Bienvenido!!')

<div class='clear'></div>
<div class='clear'></div>
