@extends('app')

@section('tittle') <h1> Servicios </h1> @endsection

@section('content')
  <div class="servicios">
    <img class="servicios-img-left" src="FotosMM/Servicios/IMG_0203.jpg" alt="" />
    <h2 class="titulo-left">Nuestro primer servicio</h2>
    <div class="descripcion-left">
      Aqui se describe nuestro primer servicio que sera
    </div>
  </div>
  <div class="servicios">
    <img class="servicios-img-right" src="FotosMM/Servicios/IMG_0203.jpg" alt="" />
    <h2 class="titulo-right">Nuestro segundo servicio</h2>
    <div class="descripcion-right">
      Aqui se describe nuestro segundo servicio que sera
    </div>
  </div>
  <div class="servicios">
    <img class="servicios-img-left" src="FotosMM/Servicios/IMG_0203.jpg" alt="" />
    <h2 class="titulo-left">Nuestro tercer servicio</h2>
    <div class="descripcion-left">
      Aqui se describe nuestro tercer servicio que sera
    </div>
  </div>
  <div class="servicios">
    <img class="servicios-img-right" src="FotosMM/Servicios/IMG_0203.jpg" alt="" />
    <h2 class="titulo-right">Nuestro cuarto servicio</h2>
    <div class="descripcion-right">
      Aqui se describe nuestro cuarto servicio que sera
    </div>
  </div>
@endsection
