<?php $__env->startSection('tittle'); ?> <h1> Contáctanos </h1> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<hr>
<div class="footer-col col-md-4">
  <center> <img src="<?php echo e(asset('img/portfolio/about_us.png')); ?>"> </center>
  <h3>Acerca de </h3>
  <p>Somos una empresa que se preocupa por sus clientes para mantener la satisfacción de estos
  lo más alta posible y así cumplir con sus expectativas
</p>
</div>


<div class="footer-col col-md-4">
  <center> <img src="<?php echo e(asset('img/portfolio/team.png')); ?>"> </center>
  <h3>¿En que puedo ayudarte?</h3>
  <p>Todo el equipo de MegaMaderas esta aqui para ayudarte a resolver cualquiera de tus dudas que tengas en
    relación a nosotros, nuestros productos, nuestros servicios. </p>
</div>



<div class="footer-col col-md-4">
  <center> <img src=<?php echo e(asset('img/portfolio/goals.png')); ?>> </center>
  <h3>Objetivo</h3>
  <p>MegaMaderas tiene como objetivo ser la mejor empresa proveedora de maderas para todos los clientes del país.</p>
</div>

<div class='col-lg-12'>
</div>

  <div class='col-lg-12'>
    <h3>Déjanos un mensaje con tus datos y nosotros te contactaremos a la brevedad.</h3>
    <p>Los tiempos de respuesta varían en relación a la demanda.</p>
  </div>

<hr>
<hr>

<!-- Contact Section -->
<section id="contact">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h2>Contact Me</h2>
                <hr class="star-primary">
            </div>
        </div>
        <div class="row">
            <div class="col-lg-8 col-lg-offset-2">
                <!-- To configure the contact form email address, go to mail/contact_me.php and update the email address in the PHP file on line 19. -->
                <!-- The form should work on most web servers, but if the form is not working you may need to configure your web server differently. -->
                <?php echo Form::open(['route' => 'contacto.store', 'method' => 'POST']); ?>

                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                              <?php echo Form::label('name', '* Nombre completo'); ?>

                              <?php echo Form::text('name',null,['class' => 'form-control', 'placeholder' => 'Nombre', 'required']); ?>

                              <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <?php echo Form::label('mail', '* Correo electrónico'); ?>

                            <?php echo Form::email('mail',null,['class' => 'form-control', 'placeholder' => 'Correo Electrónico', 'required', 'id' => 'email', 'required data-validation-required-message' => 'Porfavor ingresa una cuenta de correo valida.']); ?>

                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                          <?php echo Form::label('telephone', '* Número de teléfono'); ?>

                          <?php echo Form::text('telephone',null,['class' => 'form-control', 'placeholder' => 'Teléfono', 'required']); ?>

                          <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <div class="row control-group">
                        <div class="form-group col-xs-12 floating-label-form-group controls">
                            <?php echo Form::label('message', '* Mensaje'); ?>

                            <?php echo Form::textarea('message',null,['class' => 'form-control', 'placeholder' => 'Escribe tu mensaje...','required']); ?>

                            <p class="help-block text-danger"></p>
                        </div>
                    </div>
                    <br>
                    <div id="success"></div>
                    <div class="row">
                        <div class="form-group col-xs-12">
                            <button type="submit" class="btn btn-success btn-lg">Enviar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<div class="google" id="google">

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Google Maps API + Gmaps Plugin, must be loaded in the page you would like to use maps -->
    <script src="//maps.google.com/maps/api/js?sensor=true"></script>
    <script src="js/helpers/gmaps.min.js"></script>
<script>
    window.onload = function(){
        var options = {
            zoom: 16
            , center: new google.maps.LatLng(20.651439, -103.3272500)
            , mapTypeId: google.maps.MapTypeId.ROADMAP
        };

        var map = new google.maps.Map(document.getElementById('google'), options);

        var marcador = new google.maps.Marker({
            position: map.getCenter()
            , map: map
            , title: 'Megamaderas S.A de C.V'
            , cursor: 'default'
            , animation: google.maps.Animation.DROP

        });

        var infowindow = new google.maps.InfoWindow({ content: '<h4> << Megamaderas S.A. DE C.V. >> </h4> <p> Ven y visitamos, estamos para aclarar tus dudas.</p>' });
        infowindow.open(map, marcador);
    };
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>