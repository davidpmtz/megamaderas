<?php $__env->startSection('tittle','Productos'); ?>

<?php $__env->startSection('subtittle','Alta Producto | '); ?>

<?php $__env->startSection('subtittle2','Crear un nuevo producto para tu empresa.'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
  <div class="panel panel-info">
    <h1> Alta de producto </h2><br><br>
      <div class='Form'>
      <div class="form-group">
        <?php echo Form::open(['route' => 'admin.products.store', 'method' => 'POST', 'files' => true]); ?>

  <div class="form-group">
  <?php echo Form::label('lastModify_by', 'Creado por'); ?>

  <?php echo Form::text('lastModify_by','Waskalle',['class' => 'form-control', 'readonly' => 'readonly', 'required','hide']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('nombre', '* Nombre del producto'); ?>

    <?php echo Form::text('nombre',null,['class' => 'form-control', 'placeholder' => 'ej: Madera de Cedro', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('precio', '* Precio'); ?>

    <?php echo Form::text('precio',null,['class' => 'form-control', 'placeholder' => 'Precio de venta del producto', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('cantidad', '* Cantidad'); ?>

    <?php echo Form::number('cantidad',null,['class' => 'form-control', 'placeholder' => 'Cantidad de piezas (Entrada de almacén)', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('tipo_id', 'Tipo'); ?>

    <?php echo Form::select('tipo_id',$tipos,0,['class' => 'form-control', 'placeholder' => 'Selecciona una opción','required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('view', '* Modo de vista'); ?>

    <?php echo Form::select('view',['' => '[ Seleccionar ]','1' => 'Público',
                              '0' => 'Privado'],null,['class' => 'form-control','required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('descripcion', '* Descripción del producto'); ?>

    <?php echo Form::textarea('descripcion',null,['class' => 'form-control', 'resize' => 'none','placeholder' => 'Descripción detallada del producto', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('image','Imagen'); ?>

    <?php echo Form::file('image'); ?>

  </div>


  <div class="form-group">
    <?php echo Form::submit('Guardar',['class' => 'btn btn-success']); ?>

    <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-info">Regresar</a>
  </div>
<?php echo Form::close(); ?>

      </div>
      </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>