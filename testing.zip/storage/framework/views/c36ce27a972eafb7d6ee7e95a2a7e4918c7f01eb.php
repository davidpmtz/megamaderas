<?php $__env->startSection('tittle','Mensajes'); ?>

<?php $__env->startSection('subtittle','Contenido del mensaje de | '); ?>

<?php $__env->startSection('subtittle2'); ?>
  <?php echo e($mensaje->name); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="jumbotron">
    <h3><?php echo e($mensaje->name); ?> | <?php echo e($mensaje->email); ?></h3> <small> Número de teléfono: <?php echo e($mensaje->telephone); ?> </small>
    <small class="pull-right"> Fecha de creación: <?php echo e($mensaje->updated_at); ?> </small>
    <br />
    <br />
    <br />
<?php echo $mensaje->message; ?>

  <br />
</div>
<a href="<?php echo e(url('admin/messages')); ?>" class="btn btn-info">Regresar</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>