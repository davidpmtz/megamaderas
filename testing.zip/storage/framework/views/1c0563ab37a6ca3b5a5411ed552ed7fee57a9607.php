<?php $__env->startSection('tittle','Productos'); ?>

<?php $__env->startSection('subtittle','Productos | '); ?>

<?php $__env->startSection('subtittle2','Ver - Modificar - Borrar - Crear '); ?>

<?php $__env->startSection('activeProducts','active'); ?>

<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('Plugins/Fotos/src/css/least.min.css')); ?>" rel="stylesheet" />

<?php $__env->startSection('content'); ?>

<div class="col-lg-12">
  <div class="panel panel-info">
    <h1> Catálogo de productos </h2>
  <br>
<div class="clo-lg-12">

</div>
      <div class="clearfix"> </div>
      <div class="table-responsive">
        <table class="table">
          <div class="text-right">
            <th colspan="7">
              <a href="<?php echo e(url('admin/products/create')); ?>" class="btn btn-sm btn-info" ><i class="fa fa-plus"></i> Agregar producto </a>
            </th>
          </div>
        </table>
        <table class="table">
          <th>id</th>
          <th>Nombre</th>
          <th>Cantidad</th>
          <th>Precio</th>
          <th>Vista</th>
          <th>Status</th>
          <th>Acciones</th>
          <?php foreach($productos as $producto): ?>
          <tr>
            <td class="active"><?php echo e($producto->id); ?></td>
            <td class="success"><?php echo e($producto->nombre); ?></td>
            <td class="warning"><?php echo e($producto->cantidad); ?></td>
            <td class="danger">$<?php echo e($producto->precio); ?></td>
            <?php if($producto->view == '1'): ?>
              <td><span class="label label-success">Público</td>
            <?php else: ?>
              <td><span class="label label-danger">Privado</td>
            <?php endif; ?>
            <?php if($producto->deleted_at != null): ?>
              <td><span class="label label-danger">Eliminado</td>
            <?php else: ?>
              <td><span class="label label-success">Activo</td>
            <?php endif; ?>
            <td class="warning">
              <div class="btn-group">
                <a href="<?php echo e(route('admin.products.edit',$producto->id)); ?>" data-toggle="tooltip" title="Editar" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
                <a href="<?php echo e(route('Backend.products.destroy',$producto->id)); ?>" onclick="return confirm('¿Estas completamente seguro de que deseas eliminar el registro?')" data-toggle="tooltip" title="Borrar" class="btn btn-xs btn-default"><i class="fa fa-times"></i></a>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
      </table>
  </div>
</div>
</div>
<!-- Pagination -->
  <div class="text-right">
    <?php echo $productos->render(); ?>

  </div>
<!-- END Pagination -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>