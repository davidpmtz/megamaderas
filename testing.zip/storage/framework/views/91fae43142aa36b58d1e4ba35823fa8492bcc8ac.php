<?php $__env->startSection('tittle','Mensajes'); ?>

<?php $__env->startSection('subtittle','Mensajes de la web | '); ?>

<?php $__env->startSection('subtittle2','revisá todo lo que tus clientes han posteado en tu pagina.'); ?>


<?php $__env->startSection('content'); ?>

<?php foreach($mensajes as $mensaje): ?>
<div class="jumbotron">
    <h3><?php echo e($mensaje->name); ?> | <?php echo e($mensaje->email); ?></h3> <small> Número de teléfono: <?php echo e($mensaje->telephone); ?> </small>
    <p></p>
<?php echo str_limit($mensaje->message,214,' [...]'); ?>

  <?php if(strlen($mensaje->message) > 214): ?>
    <p> <a href="<?php echo e(url('/admin/messages3',$mensaje->id)); ?>" class="btn btn-primary btn-lg" role="button">Leer más... &raquo;</a>  </p>
  <?php endif; ?>
  <br />
  <div class="pull-right">
    <p> <a href="<?php echo e(url('/admin/messages2',$mensaje->id)); ?>" class="btn btn-success btn-lg" role="button">Responder</a>  </p>
  </div>
</div>
<?php endforeach; ?>
<div class="pull-right">
  <?php echo e($mensajes->render()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>