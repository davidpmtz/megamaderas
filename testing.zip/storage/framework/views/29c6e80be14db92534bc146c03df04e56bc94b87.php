<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">

<?php $__env->startSection('img','original.png'); ?>
<?php $__env->startSection('tittle','Bienvenido!!'); ?>

<div class='clear'></div>
<div class='clear'></div>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>