<?php $__env->startSection('tittle'); ?> <h1> Productos </h1> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <div id="divProductos">
    <?php foreach($productos as $producto): ?>
    <div class="col-sm-4 portfolio-item">
      <a href="#producto<?php echo e($producto->id); ?>" class="portfolio-link" data-toggle="modal">
          <img src="FotosMM/Herrajes/3360 70-77.jpg" class="img-responsive" alt="">
      </a>
    </div>

    <div class="portfolio-modal modal fade" id="producto<?php echo e($producto->id); ?>" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-content">
            <div class="close-modal" data-dismiss="modal">
                <div class="lr">
                    <div class="rl">
                    </div>
                </div>
            </div>
            <div class="container containerWidth">
                <div class="row">
                    <div class="col-lg-8 col-lg-offset-2">
                        <div class="modal-body">
                            <h2><?php echo e($producto->nombre); ?></h2>
                            <hr class="star-primary">
                            <img src="FotosMM/Herrajes/3360 70-77.jpg" class="img-responsive img-centered img-width" alt="">
                            <p><?php echo e($producto->descripcion); ?></p>
                            <ul class="list-inline item-details">
                            </ul>
                            <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cerrar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
    <div class="product">
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>