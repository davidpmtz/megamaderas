<?php $__env->startSection('tittle','Servicios'); ?>

<?php $__env->startSection('subtittle','Editar Servicio | '); ?>

<?php $__env->startSection('subtittle2'); ?>
<?php echo e($service->nombre); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
  <div class="panel panel-info">
    <h1> Modificar un servicio </h2><br><br>
      <div class='Form'>
      <div class="form-group">
        <?php echo Form::open(['route' => ['admin.services.update',$service], 'method' => 'PUT', 'files' => true]); ?>

  <div class="form-group">
  <?php echo Form::label('lastModify_by', 'Creado por'); ?>

  <?php echo Form::text('lastModify_by',$service->lastModify_by,['class' => 'form-control', 'readonly' => 'readonly', 'required','hide']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('nombre', '* Nombre del service'); ?>

    <?php echo Form::text('nombre',$service->nombre,['class' => 'form-control', 'placeholder' => 'ej: Madera de Cedro', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('precio', '* Precio'); ?>

    <?php echo Form::text('precio',$service->precio,['class' => 'form-control', 'placeholder' => 'Precio de venta del service', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('view', '* Modo de vista'); ?>

    <?php echo Form::select('view',['' => '[ Seleccionar ]','1' => 'Público',
                              '0' => 'Privado'],$service->view,['class' => 'form-control','required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('descripcion', '* Descripción del service'); ?>

    <?php echo Form::textarea('descripcion',$service->descripcion,['class' => 'form-control', 'resize' => 'none','placeholder' => 'Descripción detallada del service', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('image','Imagen'); ?>

    <?php echo Form::file('image'); ?>

  </div>


  <div class="form-group">
    <?php echo Form::submit('Guardar',['class' => 'btn btn-success']); ?>

    <a href="<?php echo e(route('admin.services.index')); ?>" class="btn btn-info">Regresar</a>
  </div>
<?php echo Form::close(); ?>

      </div>
      </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>