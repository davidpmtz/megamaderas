<?php $__env->startSection('tittle','Mensajes'); ?>

<?php $__env->startSection('subtittle','Mensajes de la web | '); ?>

<?php $__env->startSection('subtittle2','revisá todo lo que tus clientes han posteado en tu pagina.'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
  <div class="panel panel-info">
    <h1> Respuesta de mensaje |  <?php echo e($mensaje->name); ?></h2><br><br>
      <div class='Form'>
      <div class="form-group">
        <?php echo Form::open(['url' => 'admin/messages4', 'role' => 'form','method' => 'POST', 'files' => true]); ?>

  <div class="form-group">
  <?php echo Form::label('remitente', 'Remitente: '); ?>

  <?php echo Form::text('remitente','Megamaderas S.A de C.V',['class' => 'form-control', 'readonly' => 'readonly', 'required','hide']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('asunto', '* Asunto'); ?>

    <?php echo Form::text('asunto',null,['class' => 'form-control', 'placeholder' => 'ej: Gracias por tu preferencia.!!', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('destinatario', '* Para:'); ?>

    <?php echo Form::text('destinatario',$mensaje->email,['class' => 'form-control', 'readonly' => 'readonly', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('mensajeCliente', '* Mensaje del cliente: '); ?>

    <?php echo $mensaje->message; ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('mensaje', '* Respuesta'); ?>

    <?php echo Form::textarea('mensaje',null,['class' => 'form-control', 'resize' => 'none','placeholder' => 'Mensaje para el cliente', 'required']); ?>

  </div>
  <div class="form-group">
    <?php echo Form::label('archivo','Archivo'); ?>

    <?php echo Form::file('archivo'); ?>

  </div>


  <div class="form-group">
    <?php echo Form::submit('Enviar',['class' => 'btn btn-success']); ?>

    <a href="<?php echo e(url('admin/messages')); ?>" class="btn btn-info">Regresar</a>
  </div>
<?php echo Form::close(); ?>

      </div>
      </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>