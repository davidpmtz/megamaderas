<?php $__env->startSection('tittle','Servicios'); ?>

<?php $__env->startSection('subtittle','Servicios | '); ?>

<?php $__env->startSection('subtittle2','Ver - Modificar - Borrar - Crear '); ?>


<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-12">
    <div class="panel panel-info">
      <h1> Catálogo de servicios </h2><br><br>
        <div class="pull-right">
          <a href="<?php echo e(url('admin/services/create')); ?>" class="btn btn-sm btn-info" ><i class="fa fa-plus"></i> Agregar servicio </a>
        </div>
        <div class="clearfix"> </div>
        <div class="table-responsive">
        <table class="table">
          <th>id</th>
          <th>Nombre</th>
          <th>Precio</th>
          <th>Vista</th>
          <th>Status</th>
          <th>Acciones</th>
          <?php foreach($servicios as $servicio): ?>
          <tr>
            <td class="active"><?php echo e($servicio->id); ?></td>
            <td class="success"><?php echo e($servicio->nombre); ?></td>
            <td class="danger">$<?php echo e($servicio->precio); ?></td>
            <?php if($servicio->view == '1'): ?>
              <td><span class="label label-success">Público</td>
            <?php else: ?>
              <td><span class="label label-danger">Privado</td>
            <?php endif; ?>
            <?php if($servicio->deleted_at != null): ?>
              <td><span class="label label-danger">Eliminado</td>
            <?php else: ?>
              <td><span class="label label-success">Activo</td>
            <?php endif; ?>
            <td class="warning">
              <div class="btn-group">
                <a href="<?php echo e(route('admin.services.edit',$servicio->id)); ?>" data-toggle="tooltip" title="Editar" class="btn btn-xs btn-default"><i class="fa fa-pencil"></i></a>
                <a href="<?php echo e(route('Backend.services.destroy',$servicio->id)); ?>" onclick="return confirm('¿Estas completamente seguro de que deseas eliminar el registro?')" data-toggle="tooltip" title="Borrar" class="btn btn-xs btn-default"><i class="fa fa-times"></i></a>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
      </table>
  </div>
</div>
</div>
<!-- Pagination -->
  <div class="text-right">
    <?php echo $servicios->render(); ?>

  </div>
<!-- END Pagination -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Backend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>