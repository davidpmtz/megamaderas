<?php

namespace App\Http\Controllers\Backend;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Contacto;
use Illuminate\Pagination\Paginator;

class AdminController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//
		$res = Contacto::count();
		return view('Backend.home',['res' => $res]);
	}
	/**
	 * Show the form for see a the messages.
	 *
	 * @return Response
	 */
	public function message()
	{
		$mensajes = Contacto::paginate(3);
		return view('Backend.messages.index',['mensajes' => $mensajes]);
	}
	/**
	 * Show the form for answer a message.
	 *
	 * @return Response
	 */
	public function messageAnswer($id)
	{
		//
		$mensajes = Contacto::find($id);
		return view('Backend.messages.messageAnswer',['mensaje' => $mensajes]);

	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Responses
	 */
	 public function readMore($id)
 	{
 		$mensaje = Contacto::find($id);
 		return view('Backend.messages.readMore',['mensaje' => $mensaje]);
 	}

	/**
	*	name: sendAnswer
	* parameters: Request of form on the answer
	* return: view
	*
	**/

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function sendAnswer(Request $request)
	{
		return view ('emails.contacto',['datos' => $request]);
	}


}
